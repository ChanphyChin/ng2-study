//引入组件模块装饰器
import { Component , OnInit} from '@angular/core';
//引入hero类
import { Hero } from "../hero/hero"
//引入hero服务
import { HeroService } from "../server/hero.service"

//定义一个类，可以是引入的方式，也可以直接写在页面中。
/*export class Hero {
  id: number;
  name: string;
}*/



//定义一个数组且该数组下面的子集对象继承于Hero这个类的数据格式
/*const HEROES: Hero[] = [
  { id: 11, name: 'Mr. Nice' },
  { id: 12, name: 'Narco' },
  { id: 13, name: 'Bombasto' },
  { id: 14, name: 'Celeritas' },
  { id: 15, name: 'Magneta' },
  { id: 16, name: 'RubberMan' },
  { id: 17, name: 'Dynama' },
  { id: 18, name: 'Dr IQ' },
  { id: 19, name: 'Magma' },
  { id: 20, name: 'Tornado' }
];*/


//组件的模版
@Component({
  selector: 'app-root',
  //选择的html部分，如果要抽离出来，用templateUrl:"xxx.html"
  template: `
   <h1>{{title}}</h1>
    <h2>My Heroes</h2>
    <ul class="heroes">
      <li *ngFor="let hero of heroes"
        [class.selected]="hero === selectedHero"
        (click)="onSelect(hero)">
        <span class="badge">{{hero.id}}</span> {{hero.name}}
      </li>
    </ul>
    <hero-detail [hero]="selectedHero"></hero-detail>
  `,
  //样式引入，直接写页面中可以用style:` body{backgroud: #fff} ...... `
  styleUrls: ['./app.component.css'],
  //注册提供商，告诉注入器如何创建HeroService
  providers:[HeroService]
})

//定义数据
export class AppComponent implements OnInit {
  //定义title变量
  title = 'Tour of Heroes';
  //定义heroes变量
  heroes : Hero[];
  //定义变量的数据格式遵循上面声明的Hero这个类
  selectedHero: Hero;
  //定义点击方法
  onSelect(hero: Hero): void {
    this.selectedHero = hero;
  }

  //添加构造器
  constructor(private heroService:HeroService){};
  ngOnInit():void{
    this.getHeroes();
  }
  getHeroes():void{
    this.heroService.getHeroes().then(heroes => this.heroes = heroes);
  }

}
