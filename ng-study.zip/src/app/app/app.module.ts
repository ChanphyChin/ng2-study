//使用数据双向绑定需要引入的ngmodule组件装饰器
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
//引入表单模块装饰器
import { FormsModule }   from '@angular/forms'; // <-- NgModel lives here
 //引入入口渲染组件
import { AppComponent }  from './app.component';
//声明heroDetailComponent这个模板
import { HeroDetailComponent } from "../hero/hero-detail.component";



//定义模块的地方
@NgModule({
  imports: [
    BrowserModule,
    FormsModule // <-- import the FormsModule before binding with [(ngModel)]
  ],
  //模块声明，在这里声明之后的模板比如HeroDetailComponent,那么在AppComponent里面就可以以标签的姓氏<hero-detal></hero-detail>来渲染引进来的组件
  declarations: [
    AppComponent,
    HeroDetailComponent
  ],
  //模块渲染的模版
  bootstrap: [ AppComponent ]
})
export class AppModule { }
