//引入ng服务装饰器
import { Injectable } from '@angular/core';
//引入hero类
import { Hero } from "../hero/hero"
//引入定义好的数据
import { HEROES } from '../app/mock-heroes';

//必须从一开始就加上装饰器
@Injectable()
export class HeroService {
  //在服务器内部添加一个桩方法
  getHeroes(): Promise<Hero[]> {
    return Promise.resolve(HEROES)
  }
}

