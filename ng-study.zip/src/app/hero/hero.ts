//定义Hero类的数据格式
export class Hero {
  id:number;
  name:string;
}
