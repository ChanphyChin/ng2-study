//引入ng组件模块,输入属性装饰器
import { Component ,Input } from '@angular/core';
//引入hero类
import { Hero } from "./hero"
//定义组件
@Component({
  selector:"hero-detail",
  template:`
    <div *ngIf="hero">
      <h2>{{hero.name}} details!</h2>
      <div><label>id: </label>{{hero.id}}</div>
      <div>
        <label>name:</label>
        <input type="text" [(ngModel)]="hero.name" placeholder="name" />
      </div>
    </div>
`
})
//导出组件
export class HeroDetailComponent{
  //用@Input()装饰器声明 定义的hero变量是可读写的
  @Input() hero: Hero;
}

